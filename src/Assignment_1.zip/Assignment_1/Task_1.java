//1.	Write a Java program to print 'Hello' on screen and then print your name in a separate line.

package Assignment_1;

public class Task_1 {
    public static void main(String[] args) {
        System.out.println("Hello");
        System.out.println("Victor M Mendoza Olguin");
    }
}
