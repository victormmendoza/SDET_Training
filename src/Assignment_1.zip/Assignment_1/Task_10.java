/*
 * 10.	Write a Java program to check whether Java is installed on your computer
 */

package Assignment_1;

public class Task_10 {
	public static void main(String[] args) {
		 System.out.println("Java Version: "+System.getProperty("java.version"));
		 System.out.println("Java Runtime Version: "+System.getProperty("java.runtime.version"));
    }
}
