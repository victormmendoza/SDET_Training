package javaTest_Abstract;


public class Circle extends Figure
{
	  private double dim1;

	  public Circle(double dim1) {
	    super("Circle");
	    this.dim1 = dim1;
	  }

	  // Provide an implementation for inherited abstract draw() method
	  public void draw() {
		System.out.println("Drawing a circle...");
	  }

	  // Provide an implementation for inherited abstract getArea() method
	  public double findArea() {
	    return Math.PI * dim1 * dim1;
	  }

	  // Provide an implementation for inherited abstract getPerimeter() method
	  public double findPerimeter() {
	    return 2.0 * Math.PI * dim1;
	  }
    
}
