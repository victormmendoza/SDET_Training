package javaTest_Abstract;

public class getData {

		  public static void printShapeDetails(Figure[] list) {
		    for (int i = 0; i < list.length; i++) {
		      // Gather details about the shape		    
		      String name = list[i].getName(); // Late Binding
		      double area = list[i].findArea(); // Late binding
		      double perimeter = list[i].findPerimeter(); // Late binding

		      // Print details
		      System.out.println("\nName: " + name + "-" + (i+1));
		      System.out.println(" - Area: " + area);
		      System.out.println(" - Perimeter: " + perimeter);
		    }
		  }
}