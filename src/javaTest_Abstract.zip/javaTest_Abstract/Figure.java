package javaTest_Abstract;

public abstract class Figure {
	  private String name;
	  double dim1;

	  public Figure() {
	    this.name = "Unknown shape";
	  }

	  public Figure(String name) {
	    this.name = name;
	  }

	  public String getName() {
	    return this.name;
	  }

	  public void setName(String name) {
	    this.name = name;
	    
	  }
	  // Abstract methods
	  public abstract double findArea();

	  public abstract double findPerimeter();
}
