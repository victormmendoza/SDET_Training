package javaTest_Abstract;

public class Rectangle extends Figure
{   
    private double dim1;
    private double dim2;

    public Rectangle(double dim1, double dim2) {
      // Set the shape name as "Rectangle"
      super("Rectangle");
      this.dim1 = dim1;
      this.dim2 = dim2;
    }

    // Provide an implementation for inherited abstract draw() method
    public void draw() {
      System.out.println("Drawing a rectangle...");
    }

    // Provide an implementation for inherited abstract getArea() method
    public double findArea() {
      return dim1 * dim2;
    }

    // Provide an implementation for inherited abstract getPerimeter() method
    public double findPerimeter() {
      return 2.0 * (dim1 + dim2);
    }
    
}
